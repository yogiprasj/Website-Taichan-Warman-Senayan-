<?php
// update_admin_credentials.php
include 'includes/config.php';

// Data admin baru yang ingin diupdate
$new_credentials = [
    1 => [
        'username' => 'satetaichan1000',
        'password' => 'taichanenak1000'
    ],
    2 => [
        'username' => 'satetaichan2000', 
        'password' => 'taichanenak2000'
    ],
    3 => [
        'username' => 'satetaichan3000',
        'password' => 'taichanenak3000'
    ],
    4 => [
        'username' => 'satetaichan4000',
        'password' => 'taichanenak4000'
    ]
];

try {
    $pdo->beginTransaction();
    
    foreach ($new_credentials as $id => $credential) {
        // Hash password baru
        $hashed_password = password_hash($credential['password'], PASSWORD_DEFAULT);
        
        // Update username dan password
        $stmt = $pdo->prepare("UPDATE admins SET username = ?, password = ? WHERE id = ?");
        $stmt->execute([
            $credential['username'],
            $hashed_password,
            $id
        ]);
        
        echo "✅ Admin ID $id updated:<br>";
        echo "&nbsp;&nbsp;- Username: {$credential['username']}<br>";
        echo "&nbsp;&nbsp;- Password: {$credential['password']}<br>";
        echo "&nbsp;&nbsp;- Hashed: $hashed_password<br><br>";
    }
    
    $pdo->commit();
    echo "🎉 All admin credentials updated successfully!<br>";
    echo "📝 Don't forget to DELETE this file after use!";
    
} catch (PDOException $e) {
    $pdo->rollBack();
    echo "❌ Error: " . $e->getMessage();
}
?>